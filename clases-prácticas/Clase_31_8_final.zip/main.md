::: frame
:::

::: frame
Clase Practica Temas a desarrollar.

- Modelo de Democratización.

- Comparación método Borda y Condorcet.

- Meltzer y Richard.
:::

::: frame
Clase Práctica

![image](./PlanisferioDemocracia.jpg){width="95%"}

Figure 1: Democracy Index
:::

::: frame
Modelo simple de no democracia En 1810, la élite española concentraba el
80% de la riqueza del Virreinato del Río de la Plata. Los criollos
lograron organizarse, por lo que su poder para la revolución es alto
(Estado de la Naturaleza H). La guerra revolucionaria y el costo en
vidas asociado a ella destruiría el 30% de los recursos disponibles.

![image](./captura1.jpg){width="70%"}

Figure 2: Parametros

En este caso la **elección es R o NR**. La condición para R es
$\theta > \mu$
:::

::: frame
Grafico Revolución ![image](./captura2.png){width="70%"}
:::

::: frame
Modelo Democratización En 1992, la élite afrikaaner representaba el 21%
de la población y concentraba el 90% de los recursos de Sudáfrica. El
African National Congress (ANC) logró, luego de mucho tiempo,
organizarse de la mano de Nelson Mandela y reunir el poder de facto
necesario para la revolución (Estado de la Naturaleza H). La revolución
sería catastrófica: destruiría el 50% de la riqueza. El umbral para la
redistribución, de acuerdo con lo que está dispuesta a ceder la élite,
es de 0,7, mientras que el umbral para la democratización es de 0,3.
:::

::: frame
Modelo Democratización ![image](./captura3.jpg){width="70%"}

Figure 3: Parametros

En este caso la **elección es Revolución o Democracia.**

La condición para Revolución es $\mu < \mu^{**}$

La condición para Democracia es $\mu^{**} < \mu < \mu^{*}$

Nótese que siempre $\mu^{**} < \mu^{*}$. Para los ricos es más barata la
democracia que la revolución.
:::

::: frame
Modelo Democratización ![image](./capture5.png){width="70%"}
:::

::: frame
Modelo Democratización Nótese que dependiendo del valor de $\mu$, se
obtienen los siguientes resultados:

$$\begin{align*}
    0 < \mu < \mu^{**} &\longrightarrow \text{Revolución} \\
    \mu^{**} < \mu < \mu^{*} &\longrightarrow \text{Democracia} \\
    \mu^{*} < \mu < \theta &\longrightarrow \text{Promesa de Redistribución} \\
    \theta < \mu < 1 &\longrightarrow \text{No Revolución}
\end{align*}$$ ![image](./captura4.jpg){width="70%"}

Figure 3
:::

::: frame
Punto de partida: Meltzer-Richard

Consideramos una sociedad heterogénea dividida en dos grupos de
individuos:

- **Pobres ($p$):** Con una población $n_p$ y un ingreso exógeno de
  $y_p$.

- **Ricos ($r$):** Con una población $n_r$ y un ingreso exógeno de
  $y_r$, donde $y_r > y_p$.

La población total es $N = n_p + n_r$. Para parametrizar la estructura
social y la desigualdad, utilizamos:

- **Proporción de individuos ricos ($\delta$):**
  $$\delta = \frac{n_r}{N} \in (0, 0.5)$$ (Asumimos que los pobres son
  mayoría absoluta, por lo que $1-\delta > 0.5$).

- **Proporción del ingreso total en manos de los ricos ($\theta$):**
  $$\theta = \frac{n_r y_r}{n_r y_r + n_p y_p}$$

- **Condición de Desigualdad:** Existe desigualdad en la distribución
  del ingreso si y solo si la proporción del ingreso de los ricos supera
  a su proporción poblacional: $$\theta > \delta$$

El **ingreso promedio de la economía ($y$)** se define como:
$$y = \frac{n_p y_p + n_r y_r}{N} = (1-\delta)y_p + \delta y_r$$
:::

::: frame
Introducción de Impuesto y Corrupción

El gobierno cobra un impuesto proporcional sobre las ganancias con una
alícuota $\tau \in [0,1]$.

- **Recaudación bruta por habitante ($R$):** $$R = \tau y$$

- **Incidencia de la Corrupción ($K$):** Introducimos una filtración
  institucional representada por el parámetro fijo $K \in [0, 1)$. Este
  factor captura la fracción de la recaudación fiscal que es desviada
  por la burocracia estatal o disipada en ineficiencias antes de llegar
  a los ciudadanos en forma de beneficios públicos.

- **Transferencia per cápita neta ($T$):** El presupuesto del gobierno
  se equilibra distribuyendo el remanente neto de corrupción de forma
  uniforme (suma fija o *lump-sum*) entre todos los habitantes:
  $$T = (1-K)R \implies T = (1-K)\tau y$$
:::

::: frame
El Ingreso Directo de los Ciudadanos

El **Ingreso Directo ($y^d_i$)** de un individuo de tipo
$i \in \{p, r\}$ equivale a su ingreso neto de impuestos más la
transferencia real que efectivamente recibe del sector público:

$$y^d_i = (1-\tau)y_i + T$$

Sustituyendo el presupuesto del gobierno ajustado por corrupción:

$$y^d_i = (1-\tau)y_i + (1-K)\tau y$$
:::

::: frame
Elección Colectiva y Votación por Mayoría

Suponiendo preferencias lineales en el consumo (donde la utilidad es
igual al ingreso directo, $u^i = y^d_i$), el efecto marginal sobre el
bienestar de un individuo ante un aumento de la tasa impositiva $\tau$
viene dado por la derivada parcial:

$$\frac{\partial y^d_i}{\partial \tau} = -y_i + (1-K)y$$

De este análisis marginal se desprenden dos condiciones fundamentales de
economía política para discutir con los alumnos:

1.  **Condición de Apoyo a la Redistribución:** Un ciudadano apoyará un
    Estado de tamaño positivo ($\tau > 0$) si y solo si su beneficio
    marginal es positivo. Esto ocurre cuando su ingreso individual es
    inferior al ingreso promedio de la economía descontado por el factor
    de corrupción: $$y_i < (1-K)y$$

2.  **El Efecto de la Corrupción ($K$):** Si el Estado es perfectamente
    transparente ($K = 0$), el umbral coincide con el ingreso promedio
    estándar ($y_i < y$). A medida que la corrupción institucional
    aumenta (mayor $K$), el umbral se contrae. Si la corrupción es lo
    suficientemente alta, incluso los pobres preferirán una tasa
    impositiva de cero ($\tau = 0$), ya que lo que les quita el impuesto
    supera lo que el Estado les devuelve como transferencia.
:::

::: frame
Aplicación Numérica

Para la clase práctica, utilizaremos un *set* de datos simétrico y
sumamente limpio para facilitar las cuentas en el pizarrón:

- **Población:** $n_p = 600$ (pobres) y $n_r = 200$ (ricos). Población
  total: $N = 800$.

- **Ingresos exógenos:** $y_p = 90$ y $y_r = 180$.

- **Política fiscal propuesta:** Impuesto a las ganancias del 10%
  ($\tau = 0.10$).

- **Factor de corrupción gubernamental:** $K = 0.3$ (30% de desvío).
:::

::: frame
Paso 1: Parametrización y el Ingreso Medio

1.  **Proporción de ricos ($\delta$):**
    $$\delta = \frac{n_r}{N} = \frac{200}{800} = \mathbf{0.25} \quad (25\%)$$
    (Como $\delta = 0.25 < 0.50$, los pobres constituyen la mayoría de
    la población con el $75\%$).

2.  **Proporción del ingreso total en manos de los ricos ($\theta$):**
    $$\theta = \frac{n_r y_r}{n_p y_p + n_r y_r} = \frac{200(180)}{600(90) + 200(180)} = \frac{36000}{54000 + 36000} = \frac{36000}{90000} = \mathbf{0.40} \quad (40\%)$$

3.  **¿Existe desigualdad en esta economía?**\
    Sí. Dado que $\theta = 0.40 > 0.25 = \delta$, se verifica la
    presencia de desigualdad en la distribución del ingreso.

4.  **Ingreso promedio de la economía ($y$):**
    $$y = \frac{90000}{800} = \mathbf{112.5}$$
:::

::: frame
Paso 2: Escenario Base sin Corrupción ($K = 0$)

Evaluamos el impacto de aplicar el impuesto propuesto del 10%
($\tau = 0.10$) en una economía limpia:

1.  **Ingreso neto de impuestos del pobre (antes de transferencias):**
    $$y^n_p = (1 - \tau) y_p = (1 - 0.10) \cdot 90 = \mathbf{81}$$

2.  **Transferencia uniforme recibida ($T$):**
    $$T = \tau y = 0.10 \cdot 112.5 = \mathbf{11.25}$$

3.  **Ingreso directo final de los pobres ($y^d_p$):**
    $$y^d_p = y^n_p + T = 81 + 11.25 = \mathbf{92.25}$$

    - **Veredicto:** Dado que $92.25 > 90$, **los pobres ganan netamente
      $+2.25$** gracias al Estado de bienestar.
:::

::: frame
Paso 3: Escenario con Corrupción Institucional ($K = 0.3$)

Introducimos el desvío del 30% de la recaudación debido a la corrupción
institucional ($K = 0.3$) manteniendo la misma tasa del 10%:

1.  **Ingreso neto de impuestos del pobre:** Sigue siendo
    $y^n_p = \mathbf{81}$ (el impuesto es efectivamente retenido).

2.  **Nueva transferencia uniforme ajustada por corrupción
    ($T_{corr}$):**
    $$T_{corr} = (1 - K) \tau y = (1 - 0.3) \cdot 0.10 \cdot 112.5 = 0.7 \cdot 11.25 = \mathbf{7.875}$$
    (Se perdieron $3.375$ unidades de ingreso por habitante en las manos
    porosas del estado)

3.  **Nuevo ingreso directo final de los pobres ($y^d_{p, corr}$):**
    $$y^d_{p, corr} = y^n_p + T_{corr} = 81 + 7.875 = \mathbf{88.875}$$

    Dado que $88.875 < 90$, **los pobres ahora experimentan una pérdida
    neta de $-1.125$** de su poder adquisitivo original. La ineficiencia
    estatal y la corrupción convirtieron una política de redistribución
    en un mecanismo de empobrecimiento para la mayoría social.
:::

::: frame
Paso 4: Análisis del Equilibrio bajo Voto por Mayoría

Sometemos a votación de mayoría absoluta la tasa impositiva. Dado que
los pobres son mayoría (75% del padrón), el votante mediano es un
individuo pobre ($y_m = y_p = 90$).

1.  **Cálculo del umbral de ingresos ajustado por corrupción:**
    $$(1 - K) y = (1 - 0.3) \cdot 112.5 = 0.7 \cdot 112.5 = \mathbf{78.75}$$

2.  **Evaluación de la condición marginal para el pobre:**

    Sustituyendo en la derivada de utilidad del votante mediano pobre:
    $$\frac{\partial y^d_p}{\partial \tau} = -y_p + (1 - K) y = -90 + 78.75 = \mathbf{-11.25} < 0$$
    Dado que su ingreso exógeno supera al umbral ajustado por corrupción
    ($y_p = 90 > 78.75$), el bienestar del votante mediano pobre decrece
    de manera estrictamente lineal con cada punto de impuesto recaudado.

3.  **Resultado del Plebiscito:**

    El votante mediano pobre, anticipando que la ineficiencia fiscal
    absorberá una fracción intolerable de la riqueza, se opone a
    cualquier tasa impositiva positiva. Por lo tanto, **la alícuota de
    equilibrio elegida democráticamente por mayoría absoluta será
    $\tau^* = 0$**.
:::

::: frame
Conclusiones: Desigualdad vs. Corrupción

A partir de esta extensión del modelo de Meltzer-Richard, podemos
extraer las siguientes conclusiones:

- **El límite a la redistribución:** La simple existencia de desigualdad
  ($y_m < y$) no garantiza el apoyo social a políticas redistributivas.
  El tamaño del Estado depende críticamente de su eficiencia.

- **El umbral de tolerancia:** El votante mediano solo apoyará impuestos
  positivos si la porción de la riqueza que sobrevive a la corrupción
  supera su propio ingreso: $$y_m < (1 - K)y$$

- **Corrupción como mecanismo regresivo:** Si $K$ es muy alto, el
  sistema se invierte. Lo que el Estado retiene en impuestos es mayor a
  lo que devuelve en transferencias, empobreciendo netamente a las
  mayorías.

- **Vaciamiento democrático del Estado:** En economías con alta captura
  institucional, los ciudadanos racionales (incluso los de menores
  ingresos) preferirán desarmar el Estado de bienestar
  (**$\tau^* = 0$**) antes que financiar una burocracia extractiva.
:::

::: frame
Proyectos de Inversión Universitaria

Las alternativas entre las que tienen que votar un grupo de 100
estudiantes son:

- **Proyecto A (Biblioteca):** Ampliación de la Biblioteca Central y
  salas de estudio 24/7.

- **Proyecto B (Comedor):** Creación de un Comedor Universitario
  gratuito y saludable.

- **Proyecto C (Deportes):** Construcción de un Gimnasio de alto
  rendimiento.

- **Proyecto D (Tecnología):** Equipamiento de un Laboratorio de
  Inteligencia Artificial.

- **Proyecto E (Ecología):** Instalación de paneles solares y estaciones
  de recarga ecológicas.
:::

::: frame
Preferencias por Bloques

- **Bloque 1 (39 Representantes - Ciencias Exactas e Ingeniería):**
  Prioridad absoluta en infraestructura académica (A).
  $$P_1: A \succ B \succ C \succ D \succ E$$

- **Bloque 2 (23 Representantes - Ciencias Sociales):** Foco en el
  bienestar estudiantil (B). $$P_2: B \succ C \succ A \succ D \succ E$$

- **Bloque 3 (21 Representantes - Docentes y Personal):** Foco en salud
  y recreación (C). $$P_3: C \succ A \succ B \succ E \succ D$$

- **Bloque 4 (10 Representantes - Secretaría de Deportes):** Alineados
  con C, pero prefieren el comedor antes que la biblioteca.
  $$P_4: C \succ B \succ A \succ E \succ D$$

- **Bloque 5 (7 Representantes - Investigadores de Posgrado):** Quieren
  la biblioteca (A) y priorizan el deporte (C) para desconectar.
  $$P_5: A \succ C \succ B \succ D \succ E$$
:::

::: frame
Comparación método Borda y Condorcet Responda qué alternativa resulta
ganadora bajo los siguientes métodos de votación colectiva:

- Votación de Condorcet $\longrightarrow$ votación de a pares

- Método Borda (criterio de $n-1$) $\longrightarrow$ "ranquear
  alternativas"
:::

::: frame
Resultados: Método de Condorcet

**a) El método de Condorcet** afirma que una alternativa será la
ganadora de Condorcet si vence a todas las demás alternativas en
votaciones de a pares. Veamos el caso de $B$ vs $A$:

- (39 personas)
  $A \succ B \succ C \succ D \succ E \longrightarrow A = 39$

- (23 personas)
  $B \succ C \succ A \succ D \succ E \longrightarrow B = 23$

- (21 personas)
  $C \succ A \succ B \succ E \succ D \longrightarrow A = 21$

- (10 personas)
  $C \succ B \succ A \succ E \succ D \longrightarrow B = 10$

- (7 personas) $A \succ C \succ B \succ D \succ E \longrightarrow A = 7$

Entonces:

- $B$ vs $A \longrightarrow 33$ vs $67$ **(gana A)**
:::

::: frame
Resultados: Método de Condorcet (cont.)

Dado que $B$ perdió, seguimos con $A$ enfrentándolo a $C$:

- $A$ vs $C \longrightarrow 46$ vs $54$ **(gana C)**

Como $A$ fue derrotado, evaluamos si $C$ es el ganador enfrentándolo a
$B$:

- $C$ vs $B \longrightarrow 38$ vs $62$ **(gana B)**

Al volver a ganar $B$, se evidencia un ciclo intransitivo
($\mathbf{A \succ B \succ C \succ A}$). Ninguna alternativa logra vencer
a todas en los enfrentamientos de a pares, por lo que el ganador de
Condorcet **no existe**.
:::

::: frame
Resultados: Método de Condorcet (cont.)

Comprobemos qué sucede con los proyectos de tecnología ($D$) y ecología
($E$) frente a las alternativas principales ($A, B$ y $C$):

- $A, B$ y $C$ vs $D \longrightarrow 100$ vs $0$ **(pierde D)**

- $A, B$ y $C$ vs $E \longrightarrow 100$ vs $0$ **(pierde E)**

Ambas son alternativas dominadas por unanimidad. Finalmente, evaluamos
el duelo directo en el fondo de la tabla:

- $D$ vs $E \longrightarrow 69$ vs $31$ **(gana D)**

Conclusión de Condorcet: $E$ es el **perdedor de Condorcet** (pierde
todos sus enfrentamientos).

Sin embargo, debido al ciclo intransitivo en la cima
($\mathbf{A \succ B \succ C \succ A}$), un ganador estable **no
existe**.
:::

::: frame
Resultados: Método Borda

Aplicamos la puntuación posicional. Con esta nueva distribución, los
puntajes se dispersarán mucho más.

**Criterio $n-1$** (Puntos: 4, 3, 2, 1, 0)

- **A (Biblioteca):**
  $39(4) + 23(2) + 21(3) + 10(2) + 7(4) = \mathbf{313}$ pts

- **B (Comedor):** $39(3) + 23(4) + 21(2) + 10(3) + 7(2) = \mathbf{295}$
  pts

- **C (Deportes):**
  $39(2) + 23(3) + 21(4) + 10(4) + 7(3) = \mathbf{292}$ pts

- **D (Tecnología):**
  $39(1) + 23(1) + 21(0) + 10(0) + 7(1) = \mathbf{69}$ pts

- **E (Ecología):** $39(0) + 23(0) + 21(1) + 10(1) + 7(0) = \mathbf{31}$
  pts
:::

::: frame
Conclusión: Método Borda

(Si usamos el criterio $n$ de 5 a 1 puntos, los resultados escalan
exactamente en $+100$: $A=413$, $B=395$, $C=392$, $D=169$, $E=131$).

Entonces podemos decir que, en el método de Borda, la tabla de
posiciones final y el ganador serán exactamente los mismos, solo
cambiará la cantidad total de puntos que suma cada alternativa.

**Conclusión del análisis de Borda:**

El **Proyecto A** gana de manera contundente con $313$ puntos, sacándole
una ventaja de $18$ puntos al Proyecto B, rompiendo por completo la
sensación de empate técnico del ejercicio anterior.

Además, se observa un abismo superior a $220$ puntos frente a las otras
opciones
:::

::: frame
¿Preguntas o comentarios?
![image](./juan-roman-riquelme.jpg){width="80%"}
:::

::: frame
Reclamo Institucional ![image](./traiganunnueve.jpg){width="65%"}
:::

::: frame
**¡Muchas gracias!**

*Cátedra de Economía Política*

juan.baudino@mi.unc.edu.ar\
ramirogerardorodriguez@mi.unc.edu.ar
:::
